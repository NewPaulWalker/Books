Dependencies for the build environment for various package managers.  Used in
`.github/workflows/`.

