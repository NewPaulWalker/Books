# Nexus Trace TG reference code
Reference code for RISC-V Nexus Trace TG recommendations.<br>

Top level overview is provided here: [NexusTraceTG-RefCode.pdf](./NexusTraceTG-RefCode.pdf).

Example with additional instructions and usage details is [here](./examples/t1/README.md).
